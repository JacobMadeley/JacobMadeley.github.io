;(function(window){
	// Game
	var Game = function(el, option){
		this.el = document.getElementById(el);
		this.option = option;
		// 	Info section
		// 	Deck
		// 	Discard Pile
		// 	Rules
	}
	

	// Deck
	// 	Cards
	// 	----
	// 	shuffle
	// 	stack

	// Card
	// 	val
	// 	suit
	// 	----
	// 	flip

	// Discard Pile
	// 	Holders
	// 	----
	// 	accept or reject
	window.Game = Game;
})(window);
