	// Game
	// 	Info section
	// 	Deck
	// 	Discard Pile
	// 	Rules

	// Deck
	// 	Cards
	// 	----
	// 	shuffle
	// 	stack

	// Card
	// 	val
	// 	suit
	// 	----
	// 	flip

	// Discard Pile
	// 	Holders
	// 	----
	// 	accept or reject